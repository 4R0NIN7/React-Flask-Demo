export enum EnumUrls {
    USERS = "http://127.0.0.1:5000/users",
    CREATE_USER = "http://127.0.0.1:5000/create_user",
    UPDATE_USER = "http://127.0.0.1:5000/update_user/",
}