function convertToDisplayName(text: string): string {
  // Split the text by camel case
  const words = text.split(/(?=[A-Z])/);

  // Capitalize the first letter of the first word
  words[0] = words[0].charAt(0).toUpperCase() + words[0].slice(1);

  // Join the words with a space
  return words.join(" ");
}

export { convertToDisplayName };
