import { useFetchUsers } from "@hooks/fetch_users";
import { TUser } from "@models/user";
import { UserForm } from "@organisms/user_form/user_form";
import { UserList } from "@organisms/users_list/users_list";
import { useState } from "react";
import styled from "styled-components";

const Wrapper = styled.section`
  flex: 1;
`;

function App() {
  const { users, fetchUsers } = useFetchUsers();
  const [currentUser, setCurrentUser] = useState<TUser>();

  const editUser = (user: TUser) => {
    setCurrentUser(user);
  };
  const deleteUser = (user: TUser) => {
    setCurrentUser(user);
  };
  const closeModal = () => {
    setCurrentUser(undefined);
  };
  const onUpdate = () => {
    closeModal();
    fetchUsers();
  };

  return (
    <Wrapper>
      <UserList users={users} editUser={editUser} deleteUser={deleteUser} />
      <UserForm currentUser={currentUser} />
    </Wrapper>
  );
}

export default App;
