import { TUser } from "@models/user";
import { EnumUrls } from "@utils/constants";
import { useEffect, useState } from "react";

const useFetchUsers = () => {
  const [users, setUsers] = useState<TUser[]>([]);

  const fetchUsers = async () => {
    const response = await fetch(EnumUrls.USERS);
    const data = await response.json();
    console.log(data.users);
    setUsers(data.users);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return { users, fetchUsers };
};

export { useFetchUsers };
