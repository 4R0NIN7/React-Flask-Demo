import { TUser } from "@models/user";
import styled from "styled-components";

const Table = styled.table`
  border-collapse: collapse;
  width: 100%;
`;

const TableHeader = styled.th`
  background-color: #f2f2f2;
  border: 1px solid #ddd;
  padding: 8px;
  text-align: left;
`;

const TableRow = styled.tr`
  &:nth-child(even) {
    background-color: #f2f2f2;
  }
`;

const TableCell = styled.td`
  border: 1px solid #ddd;
  padding: 8px;
  text-align: left;
`;

const ActionButton = styled.button`
  margin-right: 5px;
  padding: 5px 10px;
  background-color: #4caf50;
  color: white;
  border: none;
  cursor: pointer;
`;

type TUserListProps = {
  users: TUser[];
  editUser: (user: TUser) => void;
  deleteUser: (user: TUser) => void;
};
const UserList = ({ users, editUser, deleteUser }: TUserListProps) => {
  if (users.length === 0) return null;
  return (
    <Table>
      <thead>
        <tr>
          <TableHeader>First Name</TableHeader>
          <TableHeader>Last Name</TableHeader>
          <TableHeader>Email</TableHeader>
          <TableHeader>Actions</TableHeader>
        </tr>
      </thead>
      <tbody>
        {users.map((user) => (
          <TableRow key={user.id}>
            <TableCell>{user.firstName}</TableCell>
            <TableCell>{user.lastName}</TableCell>
            <TableCell>{user.email}</TableCell>
            <TableCell>
              <ActionButton
                onClick={() => {
                  editUser(user);
                }}
              >
                Edit
              </ActionButton>
              <ActionButton onClick={() => deleteUser(user)}>
                Delete
              </ActionButton>
            </TableCell>
          </TableRow>
        ))}
      </tbody>
    </Table>
  );
};

export { UserList };
