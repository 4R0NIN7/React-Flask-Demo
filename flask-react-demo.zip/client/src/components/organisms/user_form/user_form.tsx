import { TUser } from "@models/user";
import { FormInput } from "@molecules/form_input/form_input";
import { EnumUrls } from "@utils/constants";
import { useEffect, useMemo, useState } from "react";

type TUserForm = {
  currentUser?: TUser;
};

const UserForm = ({ currentUser }: TUserForm) => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");

  useEffect(() => {
    if (!currentUser) return;
    const { firstName, lastName, email } = currentUser;
    setFirstName(firstName);
    setLastName(lastName);
    setEmail(email);
  }, [currentUser, setFirstName, setLastName, setEmail]);

  const createUser = async () => {
    const jsonData = {
      firstName,
      lastName,
      email,
    };
    const options = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(jsonData),
    };
    const response = await fetch(EnumUrls.CREATE_USER, options);
    if (response.status === 201 || response.status === 200) {
      const message = await response.json();
      alert(message.message);
    } else {
      const message = await response.json();
      alert(message.message);
    }
  };

  const updateUser = async () => {
    if (!currentUser) return;
    const jsonData = {
      firstName,
      lastName,
      email,
    };
    const options = {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(jsonData),
    };
    const response = await fetch(
      EnumUrls.UPDATE_USER.concat(String(currentUser.id)),
      options
    );
    if (response.status === 201 || response.status === 200) {
      const message = await response.json();
      alert(message.message);
    } else {
      const message = await response.json();
      alert(message.message);
    }
  };

  const submitText = useMemo(
    () => (currentUser ? "Update User" : "Create User"),
    [currentUser]
  );

  const onSubmit = async () => {
    if (currentUser) await updateUser()
    else await createUser()
  }

  return (
    <form onSubmit={onSubmit}>
      <div>
        <FormInput
          label="firstName"
          value={firstName}
          setValue={setFirstName}
        />
        <FormInput label="lastName" value={lastName} setValue={setLastName} />
        <FormInput label="email" value={email} setValue={setEmail} />
      </div>
      <button type="submit">{submitText}</button>
    </form>
  );
};

export { UserForm };
