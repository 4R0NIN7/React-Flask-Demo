import { convertToDisplayName } from "@utils/functions";
import { ChangeEvent } from "react";

type TFormInput = {
  label: string;
  value: string;
  setValue: (value: string) => void;
};
const FormInput = ({ label, value, setValue }: TFormInput) => {
  const onChange = (event: ChangeEvent<HTMLInputElement>) => {
    setValue(event.target.value as string);
  };
  return (
    <>
      <label htmlFor={label}>{convertToDisplayName(label)}</label>
      <input type="text" id={label} value={value} onChange={onChange}></input>
    </>
  );
};

export { FormInput };
