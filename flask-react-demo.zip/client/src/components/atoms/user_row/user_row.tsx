import { TUser } from "@models/user";

type TUserRowProps = {
  user: TUser;
};
const UserRow = ({ user }: TUserRowProps) => {
  const { firstName, lastName, id, email } = user;
  console.log(firstName, lastName, id, email);
  return (
    <tr key={id}>
      <td>{firstName}</td>
      <td>{lastName}</td>
      <td>{email}</td>
      <td>
        <button>Update</button>
        <button>Delete</button>
      </td>
    </tr>
  );
};

export { UserRow };
