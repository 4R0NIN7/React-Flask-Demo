from config import db
from dataclasses import dataclass, field
from sqlalchemy_serializer import SerializerMixin


@dataclass
class User(db.Model):
    __tablename__ = "users"

    id: int
    first_name: str
    last_name: str
    email: str

    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(80), unique=False, nullable=True)
    last_name = db.Column(db.String(80), unique=False, nullable=True)
    email = db.Column(db.String(120), unique=True, nullable=False)

    def to_json(self):
        return {
            "id": self.id,
            "firstName": self.first_name,
            "lastName": self.last_name,
            "email": self.email,
        }
