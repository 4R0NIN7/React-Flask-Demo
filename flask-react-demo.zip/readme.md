npx create-vite | client | react | typescript
from flask import flask

app = Flask(__name__)

if __name__ == "__main__":
    app.run(debug=True, port=8080)

1. CORS Handling: When React and Flask are on different domains, you need to handle “CORS” to allow them to communicate.


https://www.youtube.com/watch?v=PppslXOR7TA